% Solving the problem a'la knitro with 1st derivatives provided

function example_deriv

w1 = 100; w2 = 200; E = 30; eps = 1e-10;
 
% X = [c1, n1, c2, n2, t, T, slack1, slack2]
ub = [w2; 1 - eps; w2; 1 - eps; 1; w1 + w2; Inf; Inf];
lb = [eps; 0; eps; 0; 0; 0; 0; 0];
x0 = [w1/2; 0.6; w2/2; 0.6; 0.1; 10; 0; 0];

% indicate which variables are complementary to each other (2 to 7, 4 to 8)
extendedFeatures.ccIndexList1 = [2 4];
extendedFeatures.ccIndexList2 = [7 8];

tic
[x,fval] = knitromatlab(@(x) objective(x),x0,[],[],[],[],lb,ub,@(x) nlin_constraints(x),extendedFeatures, [], 'options_deriv.opt')
toc

function [W g] = objective(X)    
    c1 = X(1); n1 = X(2);
    c2 = X(3); n2 = X(4);
    
    % Social welfare function (times -1)
    W = - (log(c1) + log(1 - n1) + c2 - 1/(1 - n2));
    
    % Compute gradient
    if nargout == 2
        
        g(1:4) = -[1/c1; - 1/(1 - n1); 1; - 1/(1 - n2)^2];
        g(5:8) = [0; 0; 0; 0];
    end
end  

function [C Ceq GC GCeq] = nlin_constraints(X)
    c1 = X(1); n1 = X(2);
    c2 = X(3); n2 = X(4);
    t = X(5); T = X(6);
    
    C = [];
    
    % definition of the slack variables
    Ceq(1) = 1/(1 - n1) - (1 - t)*w1*1/c1 - X(7);
    Ceq(2) = 1/(1 - n2)^2 - (1 - t)*w2 - X(8);
    
    % Budget constraints of household and government
    Ceq(3) = c1 - (1 - t)*w1*n1 - T; 
    Ceq(4) = c2 - (1 - t)*w2*n2 - T;
    Ceq(5) = t*(w1*n1 + w2*n2) - E - 2*T;   
    
    % Compute derivatives
    if nargout == 4

        GC =[];
        
        GCeq(1,1:5) = [(1 - t)*w1*1/c1^2, 0, 1, 0, 0];
        GCeq(2,1:5) = [1/(1 - n1)^2, 0, - (1 - t)*w1, 0, t*w1];
        GCeq(3,1:5) = [0, 0, 0, 1, 0];
        GCeq(4,1:5) = [0, 2/(1 - n2)^3, 0, - (1 - t)*w2, t*w2];
        GCeq(5,1:5) = [w1*1/c1, w2, w1*n1, w2*n2, (w1*n1 + w2*n2)];
        GCeq(6,1:5) = [0, 0, -1, -1, -2];
        GCeq(7,1:5) = [-1, 0, 0, 0, 0];
        GCeq(8,1:5) = [0, -1, 0, 0, 0];
    end
end

end

        

    


