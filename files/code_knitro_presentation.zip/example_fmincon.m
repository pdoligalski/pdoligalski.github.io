% Solving the problem a'la fmincon

function example_fmincon

w1 = 100; w2 = 200; E = 30; eps = 1e-10;
 
% X = [c1, n1, c2, n2, t, T]
ub = [w2; 1 - eps; w2; 1 - eps; 1; w1 + w2];
lb = [eps; 0; eps; 0; 0; 0];
x0 = [w1/2; 0.6; w2/2; 0.6; 0.1; 10];

tic
[x,fval] = fmincon(@(x) objective(x),x0,[],[],[],[],lb,ub,@(x) nlin_constraints(x))

%[x,fval] = knitromatlab(@(x) objective(x),x0,[],[],[],[],lb,ub,@(x) nlin_constraints(x))
toc

function W = objective(X)    
    c1 = X(1); n1 = X(2);
    c2 = X(3); n2 = X(4);
    
    % Social welfare function (times -1)
    W = - (log(c1) + log(1 - n1) + c2 - 1/(1 - n2));
end  

function [C, Ceq] = nlin_constraints(X)
    c1 = X(1); n1 = X(2);
    c2 = X(3); n2 = X(4);
    t = X(5); T = X(6);
    
    % Non-negativity of the slack variables
    C(1) = -((1/(1 - n1) - (1 - t)*w1*1/c1));
    C(2) = -((1/(1 - n2)^2 - (1 - t)*w2));
    
    % Product of slack and labor supply equals 0
    Ceq(1) = (1/(1 - n1) - (1 - t)*w1*1/c1)*n1;
    Ceq(2) = (1/(1 - n2)^2 - (1 - t)*w2)*n2;
    
    % Budget constraints of households and government
    Ceq(3) = c1 - (1 - t)*w1*n1 - T; 
    Ceq(4) = c2 - (1 - t)*w2*n2 - T;
    Ceq(5) = t*(w1*n1 + w2*n2) - E - 2*T;    
end

end

